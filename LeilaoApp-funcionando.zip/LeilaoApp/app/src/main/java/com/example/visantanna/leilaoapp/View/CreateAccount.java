package com.example.visantanna.leilaoapp.View;

import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.visantanna.leilaoapp.R;
import com.example.visantanna.leilaoapp.base.baseActivity;
import com.example.visantanna.leilaoapp.controllers.Validator;
import com.example.visantanna.leilaoapp.db_classes.Usuario;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Created by vis_a on 17-Sep-17.
 */

public class CreateAccount extends baseActivity{
    private AppCompatEditText email;
    private AppCompatEditText senha;
    private AppCompatEditText repeteSenha;
    private AppCompatEditText nomeCompleto;
    private TextView alertaEmail;
    private TextView alertaSenha;
    private TextView alertaNome;
    private Socket socket;

    private Usuario usuario = new Usuario();

    @Override
    protected void onCreate(Bundle BundleSavedStance){
        super.onCreate(BundleSavedStance);
        setContentView(R.layout.new_account);
        mContext = getBaseContext();
        jbInit();
    }

    private void jbInit() {
        email = (AppCompatEditText)findViewById(R.id.emailTextBoxNewAccount);
        senha = (AppCompatEditText)findViewById(R.id.SenhaTextBoxNewAccount);
        repeteSenha = (AppCompatEditText)findViewById(R.id.RepeteSenhaTextBoxNewAccount);
        nomeCompleto =(AppCompatEditText)findViewById(R.id.NomeCompletoTextBoxNewAccount);
        alertaEmail = (TextView) findViewById(R.id.AlertaEmail);
        alertaSenha = (TextView) findViewById(R.id.AlertaSenha);
        alertaNome = (TextView) findViewById(R.id.AlertaNomeCompleto);

        email.setText(getIntent().getExtras().getString("email"));
        senha.setText(getIntent().getExtras().getString("senha"));
    }
    public void createNewAccount(View v){
        boolean isEmailValido = validaEmail(email.getText().toString());
        boolean isSenhaValida = validaSenha(senha.getText().toString() , repeteSenha.getText().toString());
        boolean isNomeValido  = validaNome(nomeCompleto.getText().toString() );

        if(isEmailValido && isSenhaValida && isNomeValido){
            try {
                enviaRequestNewAccount();
            }catch(Exception e){
                Log.e("Erro-enviaRequest","MENSAGEM ERRO:",e);
                System.out.println(e);
            }
        }
        else
            Toast.makeText(getApplicationContext(), "Problemas de Validação", Toast.LENGTH_SHORT).show();
    }

    private void enviaRequestNewAccount() throws IOException {

        //usado para decidir como tratar a mensagem no servidor
        usuario.setCabecalho("novo_usuario");

        Toast.makeText(getApplicationContext(), "CLICA CLICA", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            public void run() {

                try {

                    try {
                        socket = new Socket("ec2-54-244-54-160.us-west-2.compute.amazonaws.com", 9898);
                        //socket = new Socket("192.168.0.29", 9898);
                    } catch (UnknownHostException e1) {
                        e1.printStackTrace();
                        Log.e("Teste","ERRO Socket",e1);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                        Log.e("Teste","ERRO socket",e1);
                    }

                     BufferedReader in = new BufferedReader(
                             new InputStreamReader(socket.getInputStream()));


                    PrintWriter out = new PrintWriter(
                            socket.getOutputStream(), true);

                    Gson gson = new Gson();
                    String json = gson.toJson(usuario);

                    //enviando o json para o servidor
                    out.println(json);
                    out.write(json);
                    out.flush();

                    //dando um "print" do json no log
                    Log.w("JSON!!!",json);


                    String jsonIn = in.readLine();

                } catch (Exception e) {
                    Log.e("Erro-envioJson","MENSAGEM ERRO:",e);
                }
            }
        }).start();
    }

    private boolean validaSenha(String senha1, String senha2) {
        boolean isOk = true;
        if((Validator.allTrim(senha1).isEmpty())|| (Validator.allTrim(senha2).isEmpty())){
            isOk = false;
            alertaSenha.setText("Senha não foi preenchida!");
        }
        if(isOk){
            if(!senha1.equals(senha2)){
                isOk = false;
                alertaSenha.setText("As senhas são diferentes!");
            }
        }
        if(isOk){
            if(senha1.length() < 8 ){
                alertaSenha.setText("A senha deve ter 8 ou mais caracteres!");
            }
        }
        if(isOk){
            alertaSenha.setText("");

            usuario.setSenha(senha1);
        }
        return isOk;
    }


    private boolean validaNome(String nomeCompleto){
        boolean isOk = true;
        if(Validator.allTrim(nomeCompleto).isEmpty()){
            isOk = false;
            alertaNome.setText("O campo Nome está vazio!");
        }
        if(isOk){
            alertaNome.setText("");

            usuario.setNome(nomeCompleto);
        }
        return isOk;
    }

    private boolean validaEmail(String email) {
        boolean isOk = true;
        if(Validator.allTrim(email).isEmpty()){
            isOk = false;
            alertaEmail.setText("O campo de E-mail está vazio!");
        }
        if(isOk){
            usuario.setEmail(email);
            usuario.setLogin(email);

            isOk = Validator.validaEmail(email);
            if(!isOk){
                alertaEmail.setText("E-mail inválido!");
            }
        }
        if(isOk){
            alertaEmail.setText("");
        }
        return isOk;
    }
    public void setNewImage(View v){

    }

}

/*
Se alguem quiser usar toast dentro de trhead usa isso aqui:

                    runOnUiThread(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            Toast.makeText(getApplicationContext(), "Socket", Toast.LENGTH_SHORT).show();
                        }
                    });

*/
package com.testeClienteLeilao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import com.google.gson.Gson;

public class Main {


	
	public static void main(String[]args)throws IOException {

		
        // Make connection and initialize streams
        Socket socket = new Socket("127.0.0.1", 9898);
        
		
        BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));

        PrintWriter out = new PrintWriter(
                socket.getOutputStream(),true);
               
        
        Usuario usuario = new Usuario();
        
        usuario.setCabecalho("novo_usuario");
		usuario.setNome("Fabio");
		usuario.setSobrenome("Mariotto");
		usuario.setApelido("Fa");
		usuario.setSexo("M");
		usuario.setCpf("129-132-453-02");
		usuario.setRg("38122753-2");
		usuario.setTelefone_fixo("(11)4343-237");
		usuario.setTelefone_movel("(11)98797-494");
		usuario.setEmail("jullysuzuki@hotmail.com");
		usuario.setLogin("Cisco2");
		usuario.setSenha("Cisco");
		usuario.setEstado("SP");
		usuario.setCidade("Sao Paulo");
		usuario.setBairro("Mooca");
		usuario.setRua("Chamanta");
		usuario.setNumero(1042);
		usuario.setComplemento("Apto 12");
		usuario.setCEP("03127-001");
		usuario.setPontuacao(3);
        
		Gson gson = new Gson();
		String json = gson.toJson(usuario); 
		
		out.println(json);
		out.write(json);
        out.flush();
        
        /*
        StringBuilder jsonBuilder = new StringBuilder();
        
        String inputStream;
        while ((inputStream = in.readLine()) != null)
            jsonBuilder.append(inputStream);
		
        System.out.println(jsonBuilder.toString());
		
		*/
        
        String jsonIn = in.readLine();
        
        System.out.println(jsonIn);
        
        
        socket.close();
        in.close();
        out.close();
    }
	
}

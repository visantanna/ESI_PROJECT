package com.leilao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
		public static void main(String[]args) {
			
			Usuario usuario = new Usuario();
			
			usuario.setNome("Juliana");
			usuario.setSobrenome("Suzuki");
			usuario.setApelido("Jujubaa");
			usuario.setSexo("F");
			usuario.setCpf("129-132-453-02");
			usuario.setRg("38122753-2");
			usuario.setTelefone_fixo("(11)4343-2375");
			usuario.setTelefone_movel("(11)98797-4949");
			usuario.setEmail("jullysuzuki@hotmail.com");
			usuario.setLogin("Cisco2");
			usuario.setSenha("Cisco");
			usuario.setEstado("Sao Paulo");
			usuario.setCidade("Sao Paulo");
			usuario.setBairro("Mooca");
			usuario.setRua("Chamanta");
			usuario.setNumero(1042);
			usuario.setComplemento("Apto 12");
			usuario.setCEP("03127-001");
			usuario.setPontuacao(3);

			//private int cod_usuario
			
			
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			Session session = sessionFactory.openSession();
			
			//devemos usar transacoes para operacoes de insercao, remocao e modificacao.
			session.beginTransaction();
			
			session.save(usuario);
			
			session.getTransaction().commit();
			session.close();
			sessionFactory.close();
			
		}
}

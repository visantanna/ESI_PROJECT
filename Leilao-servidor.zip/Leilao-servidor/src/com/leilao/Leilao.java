package com.leilao;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "leilao")
public class Leilao {
	
	@Id
	@Column(name = "cod_leilao", columnDefinition = "serial")
	@GeneratedValue(strategy = GenerationType.IDENTITY)		
	private int cod_leilao;
	
	private String nome;
	private Date data_inicio;
	private Date data_termino;
	
	//chave estrangeira
	private int cod_lista; 
	
	//chave estrangeira
	private int cod_instituicao;
	private boolean ativo;
	
	
	public int getCod_leilao() {
		return cod_leilao;
	}
	public void setCod_leilao(int cod_leilao) {
		this.cod_leilao = cod_leilao;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getData_inicio() {
		return data_inicio;
	}
	public void setData_inicio(Date data_inicio) {
		this.data_inicio = data_inicio;
	}
	public Date getData_termino() {
		return data_termino;
	}
	public void setData_termino(Date data_termino) {
		this.data_termino = data_termino;
	}
	public int getCod_lista() {
		return cod_lista;
	}
	public void setCod_lista(int cod_lista) {
		this.cod_lista = cod_lista;
	}
	public int getCod_instituicao() {
		return cod_instituicao;
	}
	public void setCod_instituicao(int cod_instituicao) {
		this.cod_instituicao = cod_instituicao;
	}
	public boolean isAtivo() {
		return ativo;
	}
	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}
	
}

package com.leilao;

import java.io.BufferedReader;
import java.net.Socket;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;


public class ClientRequestHandler extends Thread{
	private Socket socket;
	
    public ClientRequestHandler(Socket socket) {
        this.socket = socket;
        
        log("New connection at" + socket);
    }
	
    
    
    public void run() {
    	System.out.println("CONECTAMOS");
    	
        Gson gson = new Gson();
        
        Mensagem mensagem = new Mensagem();
        
        Usuario usuario = new Usuario();
        
		
        try {
        	//usaremos "in" para ler o que o cliente mandar
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            
            
           //usamos out para mandar mensagem para o cliente 
           PrintWriter out = new PrintWriter(
                    socket.getOutputStream(),true);

            //cria uma stringbuilder para ir recebendo o json e montando-o
            //StringBuilder jsonBuilder = new StringBuilder();
          
            //inputstream contem cada parte do json e junta tudo no jsonBuilder
            //String inputStream;
            /*
            while ((inputStream = in.readLine()) != null) 
                jsonBuilder.append(inputStream);
             System.out.println("OOOIII");
            */
            //aqui passamos o json de stringbuilder para string
            //String json = jsonBuilder.toString();
            
            System.out.println("Antes de print json");
            String json = in.readLine();
            
            System.out.println(" PRINT DO JSON"+json);
            
            //vamos char o cabecalho no json
            int index = json.indexOf("cabecalho")+11;
            
            Pattern pattern = Pattern.compile("\"(.*?)\"");
            Matcher matcher = pattern.matcher(json.substring(index));
            
            
            
            
            //aqui pegamos o cabecalho
            String cabecalho;
            if (matcher.find())
            {
                cabecalho = matcher.group(1);
                
                if(cabecalho.equals("novo_usuario")) {
                	usuario = gson.fromJson(json, Usuario.class); 
                		
                		//verificando se o email inserido pelo usuario esta disponivel
                	boolean usuario_existe = verificaUsuario(usuario);
                		
                	//se o email estiver disponivel, salva no banco de dados
                	if(!usuario_existe){	
                		
                		mensagem = salvarNoBanco(usuario);
                		
                		mensagem.setMensagem("Conta criada com sucesso");
                			
                		//retorna ok para o cliente
                		json = gson.toJson(mensagem); 
                		
                		out.println(json);
                		out.write(json);
                        out.flush();
                	}
                		
                	//retorna mensagem de erro
                	mensagem.setCabecalho("erro");
            		mensagem.setMensagem("Email n�o dispon�vel");
        			
            		//retorna ok para o cliente
            		json = gson.toJson(mensagem); 
            		
            		out.println(json);
            		out.write(json);
                    out.flush();
                	
                }else if(cabecalho.equals("login")) {
                	
                	Login login = gson.fromJson(json, Login.class); 
                	
                	mensagem = autenticaUsuario(login);
                	
            		json = gson.toJson(mensagem); 
            		
            		out.println(json);
            		out.write(json);
                    out.flush();
                    
                	
                }
            }//fim controle de fluxo
                         

        } catch (IOException e) {
            log("Error handling client:" + e);
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                log("Couldn't close a socket");
            }
            log("Connection with client closed");
        }
    }
    
    //-------------------------------------------------------------
    
    public Mensagem autenticaUsuario(Login login) {
    	
    	SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory(); 
    	Session session = sessionFactory.openSession();
    	
    	Mensagem mensagem = new Mensagem();
    	
    	try {
    					
    			session.beginTransaction();
    		
    			String selectQuery = "SELECT U.email,U.senha FROM Usuario U WHERE U.email = :usernameParam AND U.senha = :userPasswordParam";
    			
    			//Session session = sessionFactory.getCurrentSession();
    	
    			Query query = session.createQuery(selectQuery);
    			query.setParameter("usernameParam", login.getEmail());
    			query.setParameter("userPasswordParam", login.getSenha());
    			@SuppressWarnings("unchecked")
    			List<Usuario> retorno_usuario = query.list();
    			
    			if(retorno_usuario!=null) {
    				mensagem.setCabecalho("usuarioAutenticado");
    				mensagem.setMensagem("Usuario autenticado com sucesso!");
    				return mensagem;
    			}else {
    				//verificando se o usuario e senha sao de uma instituicao
    				selectQuery = "SELECT I.email,I.senha FROM Instituicao I WHERE I.email = :usernameParam AND I.senha = :userPasswordParam";
        			query = session.createQuery(selectQuery);
        			//query.setParameter("usernameParam", login.getEmail());
        			//query.setParameter("userPasswordParam", login.getSenha());
    				
    				List<Instituicao> retorno_instituicao = query.list();
    				
    				if(retorno_instituicao!=null) {
        				mensagem.setCabecalho("InstituicaoAutenticada");
        				mensagem.setMensagem("Instituicao autenticada com sucesso!");
        				return mensagem;
    				}else {
        				mensagem.setCabecalho("erro");
        				mensagem.setMensagem("Email ou senha incorretos!");
        				return mensagem;
    				}
    				
    			}//fim do else
    				
    			
    	}catch(HibernateException e){
    		
    		session.getTransaction().rollback();
    		e.printStackTrace();
    		
    		mensagem.setCabecalho("erro");
    		mensagem.setMensagem(e.toString());
    		return mensagem;	
    		
    	}finally {
    		session.close();
    		sessionFactory.close();
    	}    	   	
    }//fim do metodo autenticaUsuario
    
    //-------------------------------------------------------------
    
    private boolean verificaUsuario(Usuario usuario) {
    	
    	SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory(); 
    	Session session = sessionFactory.openSession();
    
    	try {
    					
    			session.beginTransaction();
    		
    			String selectQuery = "SELECT U.email FROM Usuario U WHERE U.email = :usernameParam";
    			
    			//Session session = sessionFactory.getCurrentSession();
    	
    			Query query = session.createQuery(selectQuery);
    			query.setParameter("usernameParam", usuario.getEmail());
    			@SuppressWarnings("unchecked")
    			List<Usuario> retorno_usuario = query.list();
    			
    			
    			if(retorno_usuario!=null)
    				return true;
    			else
    				return false;
    			
    	}catch(HibernateException e){
    		session.getTransaction().rollback();
    		e.printStackTrace();
    	}finally {
    		session.close();
    		sessionFactory.close();
    	}
    	return false;
  
    }
    
    //-------------------------------------------------------------
    
    private Mensagem salvarNoBanco(Object objeto) {
    	
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();	    	
    	
		Mensagem mensagem = new Mensagem();
		
        try {       								
				//devemos usar transacoes para operacoes de insercao, remocao e modificacao.
				session.beginTransaction();
				//salva o usuario no banco
				session.save(objeto);
				
				session.getTransaction().commit();
				       			
				mensagem.setCabecalho("sucesso");
				
				return mensagem;        	
				
		} catch (HibernateException e) {
			
			session.getTransaction().rollback();
					
	        mensagem.setCabecalho("erro");
	        mensagem.setMensagem(e.toString());
	        
	        e.printStackTrace();
	        
	        return mensagem;		
			
		} finally {
			session.close();
			sessionFactory.close();
		}
        
    }//fim do metodo SalvarNoBanco
    
    //-------------------------------------------------------------
    
    private void log(String message) {
        System.out.println(message);
    } 
    
    
}

package com.leilao;

import java.io.BufferedReader;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;


public class ClientRequestHandler extends Thread{
	private Socket socket;
	
    public ClientRequestHandler(Socket socket) {
        this.socket = socket;
        
        log("New connection at" + socket);
    }
	
    
    
    public void run() {
    	System.out.println("CONECTAMOS");
        Gson gson = new Gson();
        
        Usuario usuario = new Usuario();
    	
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();	
        
        try {
        	//usaremos "in" para ler o que o cliente mandar
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            
            
           //usamos out para mandar mensagem para o cliente 
           PrintWriter out = new PrintWriter(
                    socket.getOutputStream(),true);

            //cria uma stringbuilder para ir recebendo o json e montando-o
            //StringBuilder jsonBuilder = new StringBuilder();
          
            //inputstream contem cada parte do json e junta tudo no jsonBuilder
            //String inputStream;
            /*
            while ((inputStream = in.readLine()) != null) 
                jsonBuilder.append(inputStream);
             System.out.println("OOOIII");
            */
            //aqui passamos o json de stringbuilder para string
            //String json = jsonBuilder.toString();
            
            String json = in.readLine();
            
            System.out.println(json+"oooi");
            //vamos char o cabecalho no json
            int index = json.indexOf("cabecalho")+11;
            
            Pattern pattern = Pattern.compile("\"(.*?)\"");
            Matcher matcher = pattern.matcher(json.substring(index));
            
            
            //aqui pegamos o cabecalho
            String cabecalho;
            if (matcher.find())
            {
                cabecalho = matcher.group(1);
                
                if(cabecalho.equals("novo_usuario")) {
                	usuario = gson.fromJson(json, Usuario.class); 
                	
        			try {
        				
        				//devemos usar transacoes para operacoes de insercao, remocao e modificacao.
        				session.beginTransaction();
        				//salva o usuario no banco
        				session.save(usuario);
        				
        				session.getTransaction().commit();
        				
        				//retorna ok para o cliente
        				out.println("sucesso");
        				
        			} catch (HibernateException e) {
        				session.getTransaction().rollback();
        				e.printStackTrace();
        			} finally {
        				session.close();
        				sessionFactory.close();
        				in.close();
        				out.close();
        			}	
                	
                	
                }                
                
            }
                         

        } catch (IOException e) {
            log("Error handling client:" + e);
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                log("Couldn't close a socket");
            }
            log("Connection with client closed");
        }
    }
    
    
    
    
    
    
    private void log(String message) {
        System.out.println(message);
    }
}

package com.leilao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "item")
public class Item {

	
	private String nome;
	private String categoria;
	private String descricao;
	private double lance_minimo;
	private int quantidade;
	private byte foto;
	
	@Id
	@Column(name = "cod_item", columnDefinition = "serial")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cod_item;
	private int cod_instituicao;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getLance_minimo() {
		return lance_minimo;
	}
	public void setLance_minimo(double lance_minimo) {
		this.lance_minimo = lance_minimo;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public byte getFoto() {
		return foto;
	}
	public void setFoto(byte foto) {
		this.foto = foto;
	}
	public int getCod_item() {
		return cod_item;
	}
	public void setCod_item(int cod_item) {
		this.cod_item = cod_item;
	}
	public int getCod_instituicao() {
		return cod_instituicao;
	}
	public void setCod_instituicao(int cod_instituicao) {
		this.cod_instituicao = cod_instituicao;
	}	
	
}

package com.example.visantanna.leilaoapp.View;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.visantanna.leilaoapp.R;
import com.example.visantanna.leilaoapp.base.baseActivity;
import com.example.visantanna.leilaoapp.controllers.Validator;
import com.example.visantanna.leilaoapp.db_classes.Login;
import com.example.visantanna.leilaoapp.db_classes.Mensagem;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class LoginActivity extends baseActivity {
    private AppCompatEditText email;
    private AppCompatEditText senha;
    private TextView mensagem;
    private Login login = new Login();
    private Socket socket;
    private Mensagem mensagemRetorno;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = getBaseContext();
        jbInit();
    }

    private void jbInit() {
        email = (AppCompatEditText) findViewById(R.id.emailTextBox);
        senha = (AppCompatEditText) findViewById(R.id.senhaTextBox);
        mensagem = (TextView)  findViewById(R.id.mensagem);
    }

    public void logInClicked(View button){
        String strEmail = email.getText().toString();
        String strSenha = senha.getText().toString();

        boolean emailValido = Validator.validaEmail(strEmail);
        boolean senhaValida = Validator.validaSenha(strSenha);

        if(emailValido&&senhaValida){
            mensagem.setText("");

            try {
                verificaConta(strEmail ,strSenha );
            }catch(Exception e){
                Log.e("Erro-enviaRequest","MENSAGEM ERRO:",e);
                System.out.println(e);
            }

        }else{
            mensagem.setText("Dados invalidos!");
        }
    }

    private void verificaConta(String email , String senha) throws IOException {

            //usado para decidir como tratar a mensagem no servidor
            login.setCabecalho("login");
            //coloca as informa;'oes do login validadas
            login.setSenha(senha);
            login.setEmail(email);

            Toast.makeText(getApplicationContext(), "CLICA CLICA", Toast.LENGTH_SHORT).show();
            Thread t = new Thread(new Runnable() {
                public void run() {

                    try {

                        try {
                           // socket = new Socket("ec2-54-244-54-160.us-west-2.compute.amazonaws.com", 9898);
                            socket = new Socket("192.168.0.21", 9898);
                        } catch (UnknownHostException e1) {
                            e1.printStackTrace();
                            Log.e("Teste","ERRO Socket",e1);
                        } catch (IOException e1) {
                            e1.printStackTrace();
                            Log.e("Teste","ERRO socket",e1);
                        }

                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(socket.getInputStream()));


                        PrintWriter out = new PrintWriter(
                                socket.getOutputStream(), true);

                        Gson gson = new Gson();
                        String json = gson.toJson(login);

                        //enviando o json para o servidor
                        out.println(json);
                        out.write(json);
                        out.flush();


                        String jsonIn = in.readLine();
                        Log.v("Testejson",jsonIn);
                        mensagemRetorno = gson.fromJson(jsonIn, Mensagem.class);

                        switch (mensagemRetorno.getCabecalho()){
                            case "erro":
                                mensagem.setText(mensagemRetorno.getMensagem());
                                break;
                            case "instituicaoAutenticada":
                                mensagem.setText(mensagemRetorno.getMensagem());
                                TransitionRightExtraId(HomeActivity.class, "email", login.getEmail());
                                break;
                            case "usuarioAutenticado":
                                mensagem.setText(mensagemRetorno.getMensagem());
                                TransitionRightExtraId(HomeActivity.class, "email", login.getEmail());
                                break;
                            default:
                                //dando um "print" do json no log
                                Log.w("default","algo errado no switch do cabecalho");
                                break;

                        }


                    } catch (Exception e) {
                        Log.e("Erro-envioJson","MENSAGEM ERRO:",e);
                    }
                }
            });

        t.start();
        try {
            t.join();

        }
        catch (InterruptedException e){
            Log.e("Erro-join","MENSAGEM ERRO:",e);
            System.out.println(e);
        }

    }
    public void createAccountInstituicao(View v){
        String strEmail = email.getText().toString();
        String strSenha = senha.getText().toString();
        TransitionRightExtraField(CreateAccountInst.class ,"email",strEmail ,"senha", strSenha );
    }

    public void createAccount(View v){
        String strEmail = email.getText().toString();
        String strSenha = senha.getText().toString();
        TransitionRightExtraField(CreateAccount.class ,"email",strEmail ,"senha", strSenha );
    }

    public void esqueciSenha(View v){
        String strEmail = email.getText().toString();
        String strSenha = senha.getText().toString();
        TransitionRightExtraField(RecuperaSenha.class ,"email",strEmail ,"senha", strSenha );
    }
}

package com.example.visantanna.leilaoapp.View;

import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.widget.TextView;
import android.widget.TextView;
import android.view.View;
import com.example.visantanna.leilaoapp.R;
import com.example.visantanna.leilaoapp.base.baseActivity;

/**
 * Created by daniel on 07/10/2017.
 */

public class RecuperaSenha extends baseActivity {

    @Override
    protected void onCreate(Bundle BundleSavedStance){
        super.onCreate(BundleSavedStance);
        setContentView(R.layout.recupera_senha);
        mContext = getBaseContext();
        jbInit();
    }

    private void jbInit() {

    }

}
